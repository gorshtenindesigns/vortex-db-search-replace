(function(){
    const form = document.querySelector('.vortex-container form[method="post"]');
    if (!form) return;

    const startBtn = form.querySelector('button[name="execute"]');
    const nonce = document.querySelector('input[name="vortex_db_execute_nonce"]')?.value || '';

    // Progress UI
    const resultsContainer = document.createElement('div');
    resultsContainer.className = 'vortex-ajax-results';
    form.parentNode.insertBefore(resultsContainer, form.nextSibling);

    // progress bar and cancel
    const progressWrapper = document.createElement('div');
    progressWrapper.className = 'vortex-progress-wrapper';
    progressWrapper.style.margin = '10px 0';
    progressWrapper.innerHTML = `
        <div style="background:#eee;border:1px solid #ddd;height:18px;width:100%;position:relative;">
            <div class="vortex-progress-bar" style="background:#0073aa;height:100%;width:0%;transition:width .3s;"></div>
        </div>
        <div style="margin-top:6px;"><button type="button" class="button" id="vortex-cancel">Cancel</button> <span class="vortex-progress-text"></span></div>
    `;
    resultsContainer.appendChild(progressWrapper);

    function appendLog(msg) {
        const p = document.createElement('div');
        p.textContent = msg;
        resultsContainer.appendChild(p);
    }

    function setProgress(percent, text) {
        const bar = resultsContainer.querySelector('.vortex-progress-bar');
        const txt = resultsContainer.querySelector('.vortex-progress-text');
        if (bar) bar.style.width = Math.max(0, Math.min(100, percent)) + '%';
        if (txt) txt.textContent = text || '';
    }

    function buildFormData(data) {
        const fd = new FormData();
        fd.append('action', data.action);
        fd.append('_ajax_nonce', data.nonce);
        for (const k in data.payload) {
            const v = data.payload[k];
            if (Array.isArray(v)) {
                v.forEach(x => fd.append(k + '[]', x));
            } else {
                fd.append(k, v);
            }
        }
        return fd;
    }

    async function ajaxPost(data) {
        const resp = await fetch(ajaxurl, {
            method: 'POST',
            credentials: 'same-origin',
            body: buildFormData({action: data.action, nonce: nonce, payload: data.payload})
        });
        return resp.json();
    }

    form.addEventListener('submit', async function(e){
        e.preventDefault();
        resultsContainer.innerHTML = '';
        appendLog('Preparing job...');

        const formData = new FormData(form);
        const selected_tables = formData.getAll('selected_tables[]');
        const searches = formData.getAll('searches[]');
        const replaces = formData.getAll('replaces[]');
        const dry_run = formData.get('dry_run') ? 1 : 0;
        const serialized_safe = formData.get('serialized_safe') ? 1 : 0;
        const batch_size = formData.get('batch_size') ? parseInt(formData.get('batch_size'),10) : 100;
        const backup_run = formData.get('backup_run') ? 1 : 0;

        if (selected_tables.length === 0) {
            appendLog('No tables selected.');
            return;
        }

        // Build pairs
        const pairs = [];
        for (let i = 0; i < Math.max(searches.length, replaces.length); i++) {
            const s = searches[i] || '';
            const r = replaces[i] || '';
            if (s !== '') pairs.push({search: s, replace: r});
        }
        if (pairs.length === 0) {
            appendLog('No search/replace pairs provided.');
            return;
        }

        appendLog('Requesting jobs...');
        const startResp = await ajaxPost({
            action: 'vortex_db_start',
            payload: { selected_tables, pairs_json: JSON.stringify(pairs), serialized_safe, batch_size, dry_run, backup_run }
        });

        if (!startResp.success) {
            appendLog('Error: ' + (startResp.data || 'Unknown'));
            return;
        }

        const jobs = startResp.data.jobs || [];
        let totalJobs = jobs.length;
        let doneJobs = 0;
        appendLog('Found ' + totalJobs + ' job(s). Starting processing...');

        // cancel flag
        let cancelled = false;
        const cancelBtn = resultsContainer.querySelector('#vortex-cancel');
        cancelBtn.addEventListener('click', async function(){
            appendLog('Cancel requested...');
            // call server cancel
            const c = await ajaxPost({ action: 'vortex_db_cancel', payload: {} });
            if (c && c.success) {
                appendLog('Cancel signal sent to server. Current batch will finish then stop.');
                cancelled = true;
            } else {
                appendLog('Failed to send cancel signal.');
            }
        });

        let completedJobs = 0;
        for (const job of jobs) {
            appendLog('Processing: ' + job.label + ' (estimated ' + job.count + ' rows)');
            let offset = 0;
            const jobTotal = parseInt(job.count,10) || 0;
            while (true) {
                if (cancelled) { appendLog('Job cancelled by user.'); break; }
                const proc = await ajaxPost({
                    action: 'vortex_db_process',
                    payload: { job: JSON.stringify(job), offset: offset, batch_size: batch_size, serialized_safe: serialized_safe, dry_run: dry_run, backup_run: backup_run }
                });
                if (!proc.success) {
                    appendLog('Error processing job: ' + (proc.data || 'Unknown'));
                    offset = Infinity; // break outer
                    break;
                }
                const d = proc.data;
                appendLog(d.message || JSON.stringify(d));
                // update progress bar: compute percentage from offset + processed vs jobTotal
                let processedSoFar = offset + (d.processed || 0);
                let pct = jobTotal > 0 ? Math.round((processedSoFar / jobTotal) * 100) : 0;
                setProgress(pct, job.label + ' — ' + processedSoFar + '/' + jobTotal + ' rows');
                if (d.done) break;
                offset += batch_size;
            }
            completedJobs++;
            appendLog('Job complete: ' + job.label + ' (' + completedJobs + '/' + totalJobs + ')');
            // reset progress for next job
            setProgress(0, '');
            if (cancelled) break;
        }

        appendLog('All jobs finished.');
    });
})();
