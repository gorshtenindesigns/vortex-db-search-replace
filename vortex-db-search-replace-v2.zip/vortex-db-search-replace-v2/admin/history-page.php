<?php if (!defined('ABSPATH')) exit;

if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

if (empty($_GET['_vortex_history_nonce']) || !wp_verify_nonce($_GET['_vortex_history_nonce'], 'vortex_history_export')) {
    $export_nonce_ok = false;
} else {
    $export_nonce_ok = true;
}

// Handle CSV export
if (!empty($_GET['export_runs']) && $export_nonce_ok) {
    $runs = vortex_db_get_runs(1000);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=vortex-db-runs.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, array('id','user_id','started','finished','tables','pairs','dry_run','serialized_safe','backup_run','rows_changed','status'));
    foreach ($runs as $r) {
        fputcsv($out, array(
            $r['id'], $r['user_id'], $r['started'], $r['finished'], maybe_unserialize($r['tables']) ? json_encode(maybe_unserialize($r['tables'])) : $r['tables'], maybe_unserialize($r['pairs']) ? json_encode(maybe_unserialize($r['pairs'])) : $r['pairs'], $r['dry_run'], $r['serialized_safe'], $r['backup_run'], $r['rows_changed'], $r['status']
        ));
    }
    exit;
}

// Export single run
if (!empty($_GET['export_run_id']) && $export_nonce_ok) {
    $id = intval($_GET['export_run_id']);
    global $wpdb;
    $table_name = $wpdb->prefix . 'vortex_db_runs';
    $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $id), ARRAY_A);
    if ($r) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=vortex-db-run-' . $id . '.csv');
        $out = fopen('php://output', 'w');
        fputcsv($out, array('id','user_id','started','finished','tables','pairs','dry_run','serialized_safe','backup_run','rows_changed','status','details'));
        fputcsv($out, array($r['id'], $r['user_id'], $r['started'], $r['finished'], $r['tables'], $r['pairs'], $r['dry_run'], $r['serialized_safe'], $r['backup_run'], $r['rows_changed'], $r['status'], $r['details']));
    }
    exit;
}

$runs = vortex_db_get_runs(200);
$export_link = add_query_arg(array('export_runs' => 1, '_vortex_history_nonce' => wp_create_nonce('vortex_history_export')));
?>
<div class="wrap">
    <h1>Vortex Run History</h1>
    <p><a href="<?php echo esc_url($export_link); ?>" class="button">Export All Runs (CSV)</a></p>
    <table class="widefat striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Started</th>
                <th>Finished</th>
                <th>User</th>
                <th>Tables</th>
                <th>Pairs</th>
                <th>Rows Changed</th>
                <th>Status</th>
                <th>Export</th>
            </tr>
        </thead>
        <tbody>
        <?php if (!empty($runs)): foreach ($runs as $run): ?>
            <tr>
                <td><?php echo esc_html($run['id']); ?></td>
                <td><?php echo esc_html($run['started']); ?></td>
                <td><?php echo esc_html($run['finished']); ?></td>
                <td><?php echo esc_html($run['user_id']); ?></td>
                <td style="max-width:200px; overflow:hidden;">
                    <?php $tables = maybe_unserialize($run['tables']); echo esc_html(is_array($tables) ? implode(', ', $tables) : $run['tables']); ?>
                </td>
                <td style="max-width:300px; overflow:hidden;">
                    <?php $pairs = maybe_unserialize($run['pairs']); echo esc_html(is_array($pairs) ? json_encode($pairs) : $run['pairs']); ?>
                </td>
                <td><?php echo esc_html($run['rows_changed']); ?></td>
                <td><?php echo esc_html($run['status']); ?></td>
                <td><a class="button" href="<?php echo esc_url(add_query_arg(array('export_run_id' => $run['id'], '_vortex_history_nonce' => wp_create_nonce('vortex_history_export')))); ?>">Export</a></td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="9">No runs yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
