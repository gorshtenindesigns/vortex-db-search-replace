<?php
if (!defined('ABSPATH')) exit;

add_action('admin_init', function() {
    global $wpdb;

    register_setting('vortex_db_group', 'vortex_db_settings', 'vortex_db_sanitize');

    add_settings_section(
        'vortex_db_main',
        'Vortex Search & Replace Settings',
        function() { echo '<p>Configure API key, backup, notes. All things Vortex.</p>'; },
        'vortex-db-search-replace'
    );

    add_settings_field('api_key','API Key',function(){
        $options = get_option('vortex_db_settings');
        echo "<input type='text' name='vortex_db_settings[api_key]' value='".esc_attr($options['api_key']??'')."' class='regular-text'>";
        echo "<p class='desc'>1 free site per user. $19/year for unlimited sites, unlimited searches, unlimited users.</p>";
    },'vortex-db-search-replace','vortex_db_main');

    add_settings_field('backup','Backup Before Replace',function(){
        $options = get_option('vortex_db_settings');
        $checked = !empty($options['backup']) ? 'checked' : '';
        echo "<label><input type='checkbox' name='vortex_db_settings[backup]' $checked> Enable backup before running replacements, unless your host does it for you, no problem.</label>";
    },'vortex-db-search-replace','vortex_db_main');

    add_settings_field('notes','Notes',function(){
        $options = get_option('vortex_db_settings');
        echo "<textarea name='vortex_db_settings[notes]' rows='5' class='large-text'>".esc_textarea($options['notes'] ?? '')."</textarea>";
    },'vortex-db-search-replace','vortex_db_main');
});

function vortex_db_sanitize($input) {
    $out = array();
    $out['api_key'] = isset($input['api_key']) ? sanitize_text_field($input['api_key']) : '';
    $out['backup'] = !empty($input['backup']) ? 1 : 0;
    $out['notes'] = isset($input['notes']) ? sanitize_textarea_field($input['notes']) : '';
    return $out;
}
?>
