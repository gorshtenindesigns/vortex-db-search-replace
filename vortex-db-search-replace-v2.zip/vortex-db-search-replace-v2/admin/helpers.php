<?php
if (!defined('ABSPATH')) exit;

/**
 * Recursively replace strings inside arrays/objects.
 * Returns the modified structure.
 */
function vortex_db_recursive_replace($data, $search, $replace) {
    if (is_array($data)) {
        foreach ($data as $k => $v) {
            $new = vortex_db_recursive_replace($v, $search, $replace);
            if ($new !== $v) {
                $data[$k] = $new;
            }
        }
        return $data;
    } elseif (is_object($data)) {
        $vars = get_object_vars($data);
        foreach ($vars as $k => $v) {
            $new = vortex_db_recursive_replace($v, $search, $replace);
            if ($new !== $v) {
                $data->$k = $new;
            }
        }
        return $data;
    } elseif (is_string($data)) {
        return str_replace($search, $replace, $data);
    }
    return $data;
}

/**
 * Safely detect serialized strings using WP functions if available.
 */
function vortex_db_is_serialized($data) {
    if (function_exists('is_serialized')) return is_serialized($data);
    // basic fallback
    return (@unserialize($data) !== false || $data === 'b:0;');
}

/**
 * Setup runs table (called on activation).
 */
function vortex_db_create_runs_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'vortex_db_runs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE {$table_name} (\n" .
        "  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n" .
        "  user_id bigint(20) unsigned NOT NULL,\n" .
        "  started datetime NOT NULL,\n" .
        "  finished datetime DEFAULT NULL,\n" .
        "  tables text NOT NULL,\n" .
        "  pairs text NOT NULL,\n" .
        "  dry_run tinyint(1) DEFAULT 0,\n" .
        "  serialized_safe tinyint(1) DEFAULT 0,\n" .
        "  backup_run tinyint(1) DEFAULT 0,\n" .
        "  rows_changed bigint(20) DEFAULT 0,\n" .
        "  status varchar(32) DEFAULT 'running',\n" .
        "  details longtext DEFAULT NULL,\n" .
        "  PRIMARY KEY  (id)\n" .
        ") {$charset_collate};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

/**
 * Create a new run record and return ID.
 */
function vortex_db_run_create($args) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'vortex_db_runs';
    $data = array(
        'user_id' => isset($args['user_id']) ? intval($args['user_id']) : get_current_user_id(),
        'started' => current_time('mysql'),
        'tables' => maybe_serialize($args['tables'] ?? array()),
        'pairs' => maybe_serialize($args['pairs'] ?? array()),
        'dry_run' => !empty($args['dry_run']) ? 1 : 0,
        'serialized_safe' => !empty($args['serialized_safe']) ? 1 : 0,
        'backup_run' => !empty($args['backup_run']) ? 1 : 0,
        'rows_changed' => 0,
        'status' => isset($args['status']) ? $args['status'] : 'running',
        'details' => isset($args['details']) ? maybe_serialize($args['details']) : null,
    );
    $wpdb->insert($table_name, $data);
    return $wpdb->insert_id;
}

/**
 * Update run record fields by ID.
 */
function vortex_db_run_update($run_id, $fields) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'vortex_db_runs';
    $wpdb->update($table_name, $fields, array('id' => intval($run_id)));
}

/**
 * Increment rows_changed for a run.
 */
function vortex_db_run_increment_rows($run_id, $delta) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'vortex_db_runs';
    $wpdb->query($wpdb->prepare("UPDATE {$table_name} SET rows_changed = rows_changed + %d WHERE id = %d", intval($delta), intval($run_id)));
}

/**
 * Get runs (latest first).
 */
function vortex_db_get_runs($limit = 100) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'vortex_db_runs';
    return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table_name} ORDER BY started DESC LIMIT %d", intval($limit)), ARRAY_A);
}


?>