<?php if (!defined('ABSPATH')) exit;

global $wpdb;
$tables = $wpdb->get_col("SHOW TABLES");

// include shared helpers
if (file_exists(VORTEX_DB_PATH . 'admin/helpers.php')) {
    require_once VORTEX_DB_PATH . 'admin/helpers.php';
}

// recursive replace helper is provided by admin/helpers.php

// Handle execute POST (search & replace)
$vortex_results = array();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['execute'])) {
    if (!current_user_can('manage_options')) {
        $vortex_results[] = array('error' => 'Insufficient permissions.');
    } elseif (empty($_POST['vortex_db_execute_nonce']) || !wp_verify_nonce($_POST['vortex_db_execute_nonce'], 'vortex_db_execute')) {
        $vortex_results[] = array('error' => 'Invalid request (nonce).');
    } else {
        $selected = array();
        if (!empty($_POST['selected_tables']) && is_array($_POST['selected_tables'])) {
            foreach ($_POST['selected_tables'] as $t) {
                $t = sanitize_text_field($t);
                if (in_array($t, $tables, true)) $selected[] = $t;
            }
        }

        $searches = !empty($_POST['searches']) && is_array($_POST['searches']) ? array_map('sanitize_text_field', $_POST['searches']) : array();
        $replaces = !empty($_POST['replaces']) && is_array($_POST['replaces']) ? array_map('sanitize_text_field', $_POST['replaces']) : array();

        $pairs = array();
        for ($i = 0; $i < max(count($searches), count($replaces)); $i++) {
            $s = isset($searches[$i]) ? $searches[$i] : '';
            $r = isset($replaces[$i]) ? $replaces[$i] : '';
            if ($s !== '') $pairs[] = array('search' => $s, 'replace' => $r);
        }

        $dry_run = !empty($_POST['dry_run']);
        $serialized_safe = !empty($_POST['serialized_safe']);
        $batch_size = isset($_POST['batch_size']) ? intval($_POST['batch_size']) : 100;

        $options = get_option('vortex_db_settings');
        $do_backup = !empty($options['backup']);
        // per-run override
        if (!empty($_POST['backup_run'])) {
            $do_backup = true;
        }

        if (empty($selected)) {
            $vortex_results[] = array('warning' => 'No valid tables selected.');
        } elseif (empty($pairs)) {
            $vortex_results[] = array('warning' => 'No search/replace pairs provided.');
        } else {
            // create a run record for this manual execution
            $run_id = vortex_db_run_create(array(
                'user_id' => get_current_user_id(),
                'tables' => $selected,
                'pairs' => $pairs,
                'dry_run' => $dry_run,
                'serialized_safe' => $serialized_safe,
                'backup_run' => $do_backup,
                'status' => 'running'
            ));
            $timestamp = date('YmdHis');
            foreach ($selected as $table) {
                $table = esc_sql($table);
                $table_result = array('table' => $table, 'actions' => array());

                if ($do_backup) {
                    $backup_table = $table . '_vortex_backup_' . $timestamp;
                    $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $backup_table));
                    if (!$exists) {
                        $create = $wpdb->query("CREATE TABLE `" . $backup_table . "` LIKE `" . $table . "`");
                                if ($create !== false) {
                                    $ins = $wpdb->query("INSERT INTO `" . $backup_table . "` SELECT * FROM `" . $table . "`");
                                    $table_result['actions'][] = "Backup created: {$backup_table} ({$ins} rows copied).";
                                } else {
                                    $table_result['actions'][] = "Backup failed for {$table}.";
                                }
                    } else {
                        $table_result['actions'][] = "Backup table {$backup_table} already exists, skipped backup.";
                    }
                }

                $columns = $wpdb->get_results("SHOW COLUMNS FROM `" . $table . "`", ARRAY_A);
                if (empty($columns)) {
                    $table_result['actions'][] = 'No columns found.';
                    $vortex_results[] = $table_result;
                    continue;
                }

                // helper: get primary keys for serialized-safe updates
                $primary_keys = array();
                $pk_rows = $wpdb->get_results("SHOW KEYS FROM `" . $table . "` WHERE Key_name = 'PRIMARY'", ARRAY_A);
                if (!empty($pk_rows)) {
                    foreach ($pk_rows as $pr) $primary_keys[] = $pr['Column_name'];
                }

                foreach ($columns as $col) {
                    $colname = $col['Field'];
                    // Validate column identifier to avoid SQL injection through identifier names
                    if (!preg_match('/^[A-Za-z0-9_]+$/', $colname)) {
                        continue;
                    }
                    $type = $col['Type'];
                    if (!preg_match('/char|text|blob|binary/i', $type)) continue; // only text-like columns

                    foreach ($pairs as $p) {
                        $search = $p['search'];
                        $replace = $p['replace'];
                        if ($search === '') continue;

                        $like = '%' . $wpdb->esc_like($search) . '%';
                        $count = intval($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `" . $table . "` WHERE `" . $colname . "` LIKE %s", $like)));
                        $table_result['actions'][] = sprintf("Column `%s`: %d matching rows for search '%s'", $colname, $count, $search);

                        if ($dry_run) {
                            $table_result['actions'][] = sprintf("Dry run: would update `%s` (%d rows) for search '%s'", $colname, $count, $search);
                            continue;
                        }

                        if ($serialized_safe) {
                            if (empty($primary_keys)) {
                                $table_result['actions'][] = "Serialized-safe: table `{$table}` has no primary key; falling back to SQL REPLACE for column `{$colname}` (risk of serialized corruption).";
                                // fallback to SQL REPLACE
                                $res = $wpdb->query($wpdb->prepare("UPDATE `" . $table . "` SET `" . $colname . "` = REPLACE(`" . $colname . "`, %s, %s) WHERE `" . $colname . "` LIKE %s", $search, $replace, $like));
                                if ($res === false) {
                                    $table_result['actions'][] = sprintf("Failed to update `%s` for search '%s'", $colname, $search);
                                } else {
                                    $table_result['actions'][] = sprintf("Updated `%s`: %d rows changed for search '%s' (fallback SQL)", $colname, $res, $search);
                                    if (!empty($run_id) && $res > 0) vortex_db_run_increment_rows($run_id, $res);
                                }
                            } else {
                                // process rows in batches using primary keys
                                $offset = 0;
                                $updated = 0;
                                while (true) {
                                    $select_cols = implode(', ', array_map(function($c){ return "`".$c."`"; }, $primary_keys));
                                    $query = $wpdb->prepare("SELECT " . $select_cols . ", `" . $colname . "` FROM `" . $table . "` WHERE `" . $colname . "` LIKE %s LIMIT %d, %d", $like, $offset, $batch_size);
                                    $rows = $wpdb->get_results($query, ARRAY_A);
                                    if (empty($rows)) break;
                                    foreach ($rows as $row) {
                                        $orig = $row[$colname];
                                        $newval = $orig;
                                        if (is_serialized($orig)) {
                                            $maybe = maybe_unserialize($orig);
                                            $replaced = vortex_db_recursive_replace($maybe, $search, $replace);
                                            if ($replaced !== $maybe) {
                                                $newval = maybe_serialize($replaced);
                                            }
                                        } else {
                                            // simple text replace
                                            $newval = str_replace($search, $replace, $orig);
                                        }

                                        if ($newval !== $orig) {
                                            // build where clause from primary keys
                                            $where = array();
                                            foreach ($primary_keys as $pk) {
                                                $where[$pk] = $row[$pk];
                                            }
                                            $formats = array_fill(0, count($where), '%s');
                                            $res = $wpdb->update($table, array($colname => $newval), $where, array('%s'), $formats);
                                            if ($res === false) {
                                                $table_result['actions'][] = sprintf("Failed to update row with PK %s for column `%s`", json_encode($where), $colname);
                                            } else {
                                                $updated += $res;
                                            }
                                        }
                                    }
                                    if (count($rows) < $batch_size) break;
                                    $offset += $batch_size;
                                }
                                $table_result['actions'][] = sprintf("Serialized-safe: updated `%s`: %d rows changed for search '%s'", $colname, $updated, $search);
                                if (!empty($run_id) && $updated > 0) vortex_db_run_increment_rows($run_id, $updated);
                            }
                        } else {
                            // default fast SQL replace
                            $res = $wpdb->query($wpdb->prepare("UPDATE `" . $table . "` SET `" . $colname . "` = REPLACE(`" . $colname . "`, %s, %s) WHERE `" . $colname . "` LIKE %s", $search, $replace, $like));
                            if ($res === false) {
                                $table_result['actions'][] = sprintf("Failed to update `%s` for search '%s'", $colname, $search);
                            } else {
                                $table_result['actions'][] = sprintf("Updated `%s`: %d rows changed for search '%s'", $colname, $res, $search);
                                if (!empty($run_id) && $res > 0) vortex_db_run_increment_rows($run_id, $res);
                            }
                        }
                    }
                }

                $vortex_results[] = $table_result;
            }
            // mark run finished
            if (!empty($run_id)) vortex_db_run_update($run_id, array('finished' => current_time('mysql'), 'status' => 'completed'));
        }
    }
}

?>
<div class="vortex-container">
    <h1 class="vortex-title">Vortex Database Search & Replace</h1>

    <form method="post" action="options.php">
        <?php
            settings_fields('vortex_db_group');
            do_settings_sections('vortex-db-search-replace');
        ?>
        <button type="submit" class="button-primary vortex-button">Save Settings</button>
    </form>

    <hr class="vortex-divider">
    <h2 class="vortex-subtitle">Execute Search & Replace</h2>

    <form method="post">
        <?php wp_nonce_field('vortex_db_execute', 'vortex_db_execute_nonce'); ?>
        <label><strong>Select Tables:</strong></label><br>
        <label><input type="checkbox" id="select-all-tables"> Select All Tables</label><br><br>

        <select name="selected_tables[]" multiple size="8" id="table-select" style="width:100%;">
            <?php foreach ($tables as $table): ?>
                <option value="<?php echo esc_attr($table); ?>"><?php echo esc_html($table); ?></option>
            <?php endforeach; ?>
        </select>

        <hr class="vortex-divider">

        <h3>Search / Replace Pairs</h3>
        <div id="pairs">
            <div class="pair-row">
                <input type="text" name="searches[]" placeholder="Search For" class="regular-text vortex-input">
                <input type="text" name="replaces[]" placeholder="Replace With" class="regular-text vortex-input">
            </div>
        </div>

        <button type="button" class="button" id="add-pair">+ Add More</button>

        <br><br>

        <label class="vortex-toggle">
            <input type="checkbox" name="dry_run">
            <span>Dry Run (no changes)</span>
        </label>

        <label class="vortex-toggle">
            <input type="checkbox" name="backup_run">
            <span>Per-run Backup (create backup table for this run)</span>
        </label>

        <label class="vortex-toggle">
            <input type="checkbox" name="serialized_safe">
            <span>Serialized-safe mode (slower, preserves serialized data)</span>
        </label>

        <label style="display:block; margin-top:8px;">Batch size (rows per query): <input type="number" name="batch_size" value="100" min="1" style="width:80px;"></label>

        <button type="submit" name="execute" class="button-primary vortex-button-large">Run Search & Replace</button>
    </form>

    <?php if (!empty($vortex_results)): ?>
        <hr class="vortex-divider">
        <h2>Results</h2>
        <div class="vortex-results">
            <?php foreach ($vortex_results as $r): ?>
                <div class="vortex-result-block">
                    <?php if (!empty($r['table'])): ?>
                        <h3><?php echo esc_html($r['table']); ?></h3>
                    <?php endif; ?>
                    <?php if (!empty($r['error'])): ?>
                        <p style="color:red;"><strong><?php echo esc_html($r['error']); ?></strong></p>
                    <?php endif; ?>
                    <?php if (!empty($r['warning'])): ?>
                        <p style="color:orange;"><strong><?php echo esc_html($r['warning']); ?></strong></p>
                    <?php endif; ?>
                    <?php if (!empty($r['actions']) && is_array($r['actions'])): ?>
                        <ul>
                        <?php foreach ($r['actions'] as $a): ?>
                            <li><?php echo esc_html($a); ?></li>
                        <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <hr class="vortex-divider">

    <h2>About the Developer</h2>
    <p><strong>Yan Gorshtenin – Vortex Solutions</strong><br>
    Senior Full-Stack Developer & WordPress Specialist.<br>
    Custom plugin development, API integrations, advanced automation.</p>
</div>

<script>
document.getElementById('select-all-tables').addEventListener('change', function() {
    const sel = document.getElementById('table-select');
    for (let i = 0; i < sel.options.length; i++) {
        sel.options[i].selected = this.checked;
    }
});

document.getElementById('add-pair').addEventListener('click', function() {
    const container = document.getElementById('pairs');
    const row = document.createElement('div');
    row.className = 'pair-row';
    row.innerHTML = `
        <input type="text" name="searches[]" placeholder="Search For" class="regular-text vortex-input">
        <input type="text" name="replaces[]" placeholder="Replace With" class="regular-text vortex-input">
    `;
    container.appendChild(row);
});
</script>
