<?php
/**
 * Plugin Name: Vortex Advanced DB Search & Replace
 * Description: Modernized search/replace plugin with multi-table, multi-field replacements, API key, backup toggle, and clean admin UI.
 * Author: Yan Gorshtenin (Vortex Solutions)
 * Version: 2.1
 */

if (!defined('ABSPATH')) exit;

define('VORTEX_DB_PATH', plugin_dir_path(__FILE__));
define('VORTEX_DB_URL', plugin_dir_url(__FILE__));

require_once VORTEX_DB_PATH . 'admin/settings-register.php';

add_action('admin_menu', function() {
    add_options_page(
        'Vortex DB Search & Replace',
        'Vortex Search & Replace',
        'manage_options',
        'vortex-db-search-replace',
        'vortex_db_admin_page'
    );
});

add_action('admin_enqueue_scripts', function($hook) {
    if ($hook === 'settings_page_vortex-db-search-replace') {
        wp_enqueue_style('vortex-db-admin', VORTEX_DB_URL . 'assets/css/admin.css');
        wp_enqueue_script('vortex-db-admin-js', VORTEX_DB_URL . 'assets/js/admin.js', array('jquery'), '2.1', true);
        wp_localize_script('vortex-db-admin-js', 'VortexDB', array(
            'ajax_url' => admin_url('admin-ajax.php'),
        ));
    }
});

function vortex_db_admin_page() {
    require VORTEX_DB_PATH . 'admin/settings-page.php';
}

// include helpers for AJAX
if (file_exists(VORTEX_DB_PATH . 'admin/helpers.php')) {
    require_once VORTEX_DB_PATH . 'admin/helpers.php';
}

// Activation hook: create runs table
register_activation_hook(__FILE__, 'vortex_db_activate');
function vortex_db_activate() {
    if (file_exists(VORTEX_DB_PATH . 'admin/helpers.php')) {
        require_once VORTEX_DB_PATH . 'admin/helpers.php';
        vortex_db_create_runs_table();
    }
}

// add history submenu
add_action('admin_menu', function() {
    add_submenu_page(
        'options-general.php',
        'Vortex Run History',
        'Vortex Run History',
        'manage_options',
        'vortex-db-search-replace-history',
        'vortex_db_history_page'
    );
});

function vortex_db_history_page() {
    require VORTEX_DB_PATH . 'admin/history-page.php';
}

// AJAX: prepare jobs (returns list of table/column/pair jobs)
add_action('wp_ajax_vortex_db_start', function(){
    if (!current_user_can('manage_options')) wp_send_json_error('Insufficient permissions');
    check_ajax_referer('vortex_db_execute', '_ajax_nonce', true);
    global $wpdb;

    $selected = isset($_POST['selected_tables']) ? (array) $_POST['selected_tables'] : array();
    $pairs = array();
    if (!empty($_POST['pairs_json'])) {
        $pairs = json_decode(stripslashes($_POST['pairs_json']), true);
    }
    $serialized_safe = !empty($_POST['serialized_safe']);
    $batch_size = isset($_POST['batch_size']) ? intval($_POST['batch_size']) : 100;
    $dry_run = !empty($_POST['dry_run']);
    $backup_run = !empty($_POST['backup_run']);

    $tables = $wpdb->get_col("SHOW TABLES");
    $jobs = array();

    // create a run record to track this job
    $run_id = vortex_db_run_create(array(
        'user_id' => get_current_user_id(),
        'tables' => $selected,
        'pairs' => $pairs,
        'dry_run' => $dry_run,
        'serialized_safe' => $serialized_safe,
        'backup_run' => $backup_run,
        'status' => 'running'
    ));

    foreach ($selected as $table) {
        $table = sanitize_text_field($table);
        if (!in_array($table, $tables, true)) continue;
        $cols = $wpdb->get_results("SHOW COLUMNS FROM `" . esc_sql($table) . "`", ARRAY_A);
        if (empty($cols)) continue;
        foreach ($cols as $col) {
            $colname = $col['Field'];
            if (!preg_match('/^[A-Za-z0-9_]+$/', $colname)) continue;
            $type = $col['Type'];
            if (!preg_match('/char|text|blob|binary/i', $type)) continue;
            foreach ($pairs as $p) {
                $search = isset($p['search']) ? $p['search'] : '';
                if ($search === '') continue;
                $like = '%' . $wpdb->esc_like($search) . '%';
                $count = intval($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM `" . $table . "` WHERE `" . $colname . "` LIKE %s", $like)));
                $jobs[] = array(
                    'table' => $table,
                    'column' => $colname,
                    'search' => $search,
                    'replace' => isset($p['replace']) ? $p['replace'] : '',
                    'count' => $count,
                    'batch_size' => $batch_size,
                    'serialized_safe' => $serialized_safe,
                    'dry_run' => $dry_run,
                    'backup_run' => $backup_run,
                    'label' => $table . '.' . $colname . ' => ' . $search,
                    'run_id' => $run_id
                );
            }
        }
    }

    wp_send_json_success(array('jobs' => $jobs));
});

// AJAX: process a batch for a single job
add_action('wp_ajax_vortex_db_process', function(){
    if (!current_user_can('manage_options')) wp_send_json_error('Insufficient permissions');
    check_ajax_referer('vortex_db_execute', '_ajax_nonce', true);
    global $wpdb;

    $job = isset($_POST['job']) ? json_decode(stripslashes($_POST['job']), true) : null;
    $offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
    $batch_size = isset($_POST['batch_size']) ? intval($_POST['batch_size']) : 100;
    if (!$job) wp_send_json_error('Invalid job');

    $table = sanitize_text_field($job['table']);
    $colname = sanitize_text_field($job['column']);
    $search = (string) $job['search'];
    $replace = (string) $job['replace'];
    $serialized_safe = !empty($job['serialized_safe']);
    $dry_run = !empty($job['dry_run']);
    $backup_run = !empty($job['backup_run']);
    $run_id = !empty($job['run_id']) ? intval($job['run_id']) : 0;

    // respect cancel request
    $cancel_key = 'vortex_db_cancel_' . get_current_user_id();
    if (get_transient($cancel_key)) {
        delete_transient($cancel_key);
        wp_send_json_success(array('done' => true, 'canceled' => true, 'message' => 'Canceled by user'));
    }

    // create per-run backup on first batch
    if ($backup_run && $offset === 0) {
        $timestamp = date('YmdHis');
        $backup_table = $table . '_vortex_backup_' . $timestamp;
        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $backup_table));
        if (!$exists) {
            $create = $wpdb->query("CREATE TABLE `" . $backup_table . "` LIKE `" . $table . "`");
            if ($create !== false) {
                $wpdb->query("INSERT INTO `" . $backup_table . "` SELECT * FROM `" . $table . "`");
            }
        }
    }

    $like = '%' . $wpdb->esc_like($search) . '%';

    if ($dry_run) {
        wp_send_json_success(array('done' => true, 'message' => 'Dry run - nothing changed', 'processed' => 0));
    }

    if ($serialized_safe) {
        // get primary keys
        $primary_keys = array();
        $pk_rows = $wpdb->get_results("SHOW KEYS FROM `" . $table . "` WHERE Key_name = 'PRIMARY'", ARRAY_A);
        if (!empty($pk_rows)) {
            foreach ($pk_rows as $pr) $primary_keys[] = $pr['Column_name'];
        }
        if (empty($primary_keys)) {
            // fallback to SQL replace for this batch
            $res = $wpdb->query($wpdb->prepare("UPDATE `" . $table . "` SET `" . $colname . "` = REPLACE(`" . $colname . "`, %s, %s) WHERE `" . $colname . "` LIKE %s LIMIT %d", $search, $replace, $like, $batch_size));
            if ($res === false) wp_send_json_error('SQL replace failed');
            wp_send_json_success(array('done' => true, 'message' => "Fallback SQL updated {$res} rows"));
        }

        // select rows with PKs and column
        $select_pk = implode(', ', array_map(function($c){ return "`".$c."`"; }, $primary_keys));
        $query = $wpdb->prepare("SELECT " . $select_pk . ", `" . $colname . "` FROM `" . $table . "` WHERE `" . $colname . "` LIKE %s LIMIT %d, %d", $like, $offset, $batch_size);
        $rows = $wpdb->get_results($query, ARRAY_A);
        if (empty($rows)) {
            wp_send_json_success(array('done' => true, 'message' => 'No more rows', 'processed' => 0));
        }
        $processed = 0;
        foreach ($rows as $row) {
            $orig = $row[$colname];
            $newval = $orig;
            if (vortex_db_is_serialized($orig)) {
                $maybe = maybe_unserialize($orig);
                $replaced = vortex_db_recursive_replace($maybe, $search, $replace);
                if ($replaced !== $maybe) {
                    $newval = maybe_serialize($replaced);
                }
            } else {
                $newval = str_replace($search, $replace, $orig);
            }
            if ($newval !== $orig) {
                $where = array();
                foreach ($primary_keys as $pk) {
                    $where[$pk] = $row[$pk];
                }
                $formats = array_fill(0, count($where), '%s');
                $res = $wpdb->update($table, array($colname => $newval), $where, array('%s'), $formats);
                if ($res !== false) $processed += $res;
            }
        }
        $done = count($rows) < $batch_size;
        if ($run_id && $processed > 0) vortex_db_run_increment_rows($run_id, $processed);
        if ($done && $run_id) vortex_db_run_update($run_id, array('finished' => current_time('mysql'), 'status' => 'completed'));
        wp_send_json_success(array('done' => $done, 'message' => "Processed {$processed} rows (offset {$offset})", 'processed' => $processed));
    }

    // default fast SQL replace processing for a batch
    $res = $wpdb->query($wpdb->prepare("UPDATE `" . $table . "` SET `" . $colname . "` = REPLACE(`" . $colname . "`, %s, %s) WHERE `" . $colname . "` LIKE %s LIMIT %d", $search, $replace, $like, $batch_size));
    if ($res === false) wp_send_json_error('SQL replace failed');
    $done = ($res < $batch_size);
    if ($run_id && $res > 0) vortex_db_run_increment_rows($run_id, $res);
    if ($done && $run_id) vortex_db_run_update($run_id, array('finished' => current_time('mysql'), 'status' => 'completed'));
    wp_send_json_success(array('done' => $done, 'message' => "Updated {$res} rows (offset {$offset})", 'processed' => $res));
});

// AJAX: cancel currently running job for this user (sets a transient flag)
add_action('wp_ajax_vortex_db_cancel', function(){
    if (!current_user_can('manage_options')) wp_send_json_error('Insufficient permissions');
    check_ajax_referer('vortex_db_execute', '_ajax_nonce', true);
    $user = get_current_user_id();
    if (!$user) wp_send_json_error('No user');
    $key = 'vortex_db_cancel_' . $user;
    set_transient($key, 1, 300); // 5 minutes
    wp_send_json_success('cancelled');
});
